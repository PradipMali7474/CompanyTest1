package CompanyTest;

public class LongestString {
	public static void main(String[] args) {
		String a="dummy text of the printing and typesetting industry";
		String b=" ";
		String str[]=a.split(" ");
		
		for(int i=0;i<str.length;i++)
		{
			for(int j=1+i;j<str.length;j++)
			{
				if(str[i].length()>=str[j].length())
				{
					b=str[i];
				}
			}
		}
           System.out.println("Longest String = "+b);
	}

}

package CompanyTest;

import RobbitTourtoise.AcceptTwoNumber;

public class FetchesNumber extends AcceptTwoNumber {
	
	public int num1;
	public int num2;
	
	public FetchesNumber(AcceptTwoNumber number)
	{
		num1=number.GetNo1() % 10;
		num2=number.GetNo2() % 10;
	}
	public int GetNum1() {
		return num1;
	}
	public int GetNum2() {
		return num2;
	}
 }
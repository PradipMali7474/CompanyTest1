package CompanyTest;

public class AcceptTwoNumber {
	
	public int no1;
	public int no2;
	
	public int AcceptTwoNumber(int no1, int no2) {
	   return no1;
	}
	
	public int GetNo1() {
		return no1;	
	}
	public int GetNo2()
	{
		return no2;
		
	}

}

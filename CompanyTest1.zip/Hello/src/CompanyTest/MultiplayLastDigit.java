package CompanyTest;

import RobbitTourtoise.AcceptTwoNumber;
import RobbitTourtoise.FetchesNumber;

public class MultiplayLastDigit extends FetchesNumber{

	public MultiplayLastDigit(AcceptTwoNumber number) {
		super(number);
		
	}
	int res;
	public int MultiplayLastDigit(FetchesNumber fetchesnumber)
	{
		return res;
	}
	
	}
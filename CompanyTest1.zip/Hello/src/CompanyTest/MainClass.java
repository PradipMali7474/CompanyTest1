package CompanyTest;

import RobbitTourtoise.AcceptTwoNumber;
import RobbitTourtoise.FetchesNumber;
import RobbitTourtoise.MultiplayLastDigit;

public class MainClass {
public static void main(String[] args) {
		
		AcceptTwoNumber number=new AcceptTwoNumber();
		FetchesNumber fetchesnumber=new FetchesNumber(number);
		MultiplayLastDigit mul=new MultiplayLastDigit(fetchesnumber);
		System.out.println(number);
	}

}
